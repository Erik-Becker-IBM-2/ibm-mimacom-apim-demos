UC 6 API security on zrh-nano: >-
  Product security-zrh with three APIs on the same operations (GET/POST
  /flights, GET /flights/{flight}, GET /delay/{seconds}) and backend go-httpbin
  (http://httpbin.uc6-backend:8080, echoes the forwarded request). Only security
  policies of the Nano gateway are used; what Nano does not provide is listed as
  gap below, not rebuilt with scripts. FlightsOAuthApi (/oauth): Entra client
  credential token, validated by OAuthProvider entra-demo with JWTProvider
  entra-demo-jwt (platform/overlays/zrh-gw/uc6-security): signature, issuer,
  audience, expiry (local JWKS, no introspection). SEC_If_MissingRole requires
  the app role Flight.Reader (roles claim); client-noaccess (valid token, no
  roles) gets 403 from the gateway. Rate limit per API 20/min. FlightsApiKeyApi
  (/apikey): client ID and secret, rate limit per consumer 10/min. Basic Auth is
  in project UC6_Security_DP (DataPower API Gateway). Shared on both: IP
  denylist (SEC_IpBlock, TEST-NET placeholder), JSON limits on POST (4 KB, depth
  5), request validation against the OpenAPI spec, backend Basic Auth from
  Kubernetes secret uc6-backend-basic (ExternalSecret from Key Vault), backend
  timeout 3 s on /delay.

  Drehbuch step → Nano (native / verify / gap): OAuth/OIDC with Entra: native
  token validation (ExtractIdentity and Authenticate oauth2 with a JWKS-backed
  provider). Studio jwt policies would need the provider registered in the API
  Manager catalog (SaaS pushes it to the gateway under a hashed name); Authorize
  is left out because its scope check needs introspection. Role/claim check: If
  + Throw (SEC_If_MissingRole). Nano's JSONata has no access to token claims
  (extension functions: body, bodyType, extractIdentityTypes, gtid, header,
  headers, httpMethod, pathAndQuery, pathParameter, queryParameter,
  queryParametersAll, relativeUrl, requestProperty, statusCode, statusMessage,
  telemetry, variable) and no base64url decoding, so the payload segment of the
  validated token in $header('request', 'Authorization') is searched for
  "Flight.Reader" in its three base64 alignments. Workaround, not a policy
  feature. Native scope check (Authorize oauth2 requiredScopes) needs a provider
  with remote introspection, which Entra does not offer (runtime: "Provider ...
  does not support remote introspection"). The OpenAPI definition cannot declare
  the token: Nano rejects bearer schemes at publish and oauth2 schemes (nested
  flows) on the gateway, so FlightsOAuthApi has no security scheme; the assembly
  enforces the token. API key: native (ExtractIdentity apiKey, Authenticate
  subscription). Basic Auth: gap on Nano (no user registry policy; API Manager
  rejects a basic security scheme without registry). Shown on the DataPower API
  Gateway with user-security and an authentication URL registry
  (UC6_Security_DP). Schema validation: native (ValidateAPISpecification) for
  request bodies (wrong type, missing field → 400, tested 26.10.); query
  parameters are not enforced (status=LANDED outside the enum → 200).
  Signature-based attack detection: not usable on Nano 12.1.1 (gap, report to
  IBM). SQLInjectionFilter with predefined keywordInjection or likeMatch rejects
  every request (also /oauth/flights without query) with HTTP 500 "Request
  rejected"; the generated Runtime has no pattern definitions
  (spec.sqlInjectionFilters empty) and they cannot be set from Studio or
  RuntimeConfig. Studio's orAndAttack is andOrAttack on the gateway.
  escapeSequence and metacharacters not tested. Filters removed from the APIs;
  XSS and other CRS rule classes are not offered at all. Rate limit and quota
  per consumer and API: native with inline RateLimit definitions (per API:
  SEC_RateLimitDef_OAuth 20/min; per consumer: SEC_RateLimitDef_Consumer 10/min
  keyed by X-IBM-Client-Id via dynamicValue; consumerSpecific: true failed the
  Studio publish with "Cannot read properties of undefined (reading
  'metadata')"). A plan quota (Plan withQuota + Quota) reaches the runtime
  without exceedAction and is not enforced (16 calls/min accepted, tested
  26.10.). It stays in SEC_Plan with SEC_RateLimit_Plan consuming the alias: API
  Manager rejects unused plan aliases, and the Studio publish failed without a
  plan quota. Timeout: native for the backend (Invoke timeout); gap for a
  gateway-side request timeout. Payload size: native (Parse maxDocumentSize,
  JSON only); gap for XML threat protection. IP blocklist: native (Block). Brute
  force, bot, replay: gap (no policy; quota and IP block are the nearest
  controls, no jti/nonce handling). Key Vault: gap for native access; secrets
  are Kubernetes secrets by name, filled from Key Vault by the External Secrets
  Operator. mTLS per API: TLS server profiles per listener and SNI host, not per
  API (spike S2).

  To verify on first publish: $header('request', 'Authorization') in
  SEC_If_MissingRole, OAuthProvider lookup by name from the Studio policies,
  SetAuthorization secret format (kubernetes.io/basic-auth) and read access of
  the runtime to it, Quota interval syntax (60s).
