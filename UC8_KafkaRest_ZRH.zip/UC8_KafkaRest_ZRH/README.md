UC 8 REST to Kafka on zrh-nano: >-
  Kafka REST Proxy v2 on SNO B (http://kafka-rest.kafka:8082). Plain HTTP
  in-cluster, so no TLS client profile on the invokes. KR_OperationSwitch routes
  each operation to its invoke; path parameters go into the backend URL via
  $pathParameter() (the Nano runtime has no $encodeUrlComponent). Produce: POST
  /topics/{topic}. Consume: POST /consumers/{group}, POST
  .../instances/{instance}/subscription, GET .../records, DELETE
  .../instances/{instance}. Consumer instances live in the single proxy pod and
  expire after 5 min without polling. One-call consume GET
  /topics/{topic}/groups/{group}/records runs create, subscribe, fetch and
  delete in the gateway (KR_Set_Consume* and KR_Invoke_Consume*): consumer
  instance gw-<group>, backend URLs and bodies as JSONata with $pathParameter(),
  separate messages kafkaRequest and kafkaRecords for the backend calls, only
  the fetch writes to response. Subscribe and fetch run in
  KR_Try_ConsumeRecords; its finally deletes the consumer instance also when one
  of them fails.
