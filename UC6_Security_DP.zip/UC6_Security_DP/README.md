UC 6 Basic Auth on the DataPower API Gateway: >-
  Product security-dp in catalog sandbox of the SaaS tenant (IBM-hosted
  DataPower API Gateway apic-gwv6a-xik). FlightsBasicApi (/basic, GET /flights):
  user-security policy with Basic Auth against the authentication URL user
  registry uc6-basic (API Manager resource, enabled for APIs in sandbox), fixed
  sample response from a GatewayScript. Split from UC6_Security_ZRH because the
  Nano gateway has no user registry policy and API Manager rejects a basic
  security scheme without a registry. Registry endpoint (reachable from the SaaS
  gateway): go-httpbin on SNO B via route httpbin-basic-auth (only /basic-auth
  exposed),
  https://uc6-auth.apps.sno-b.apim.fzag-demo.mimacom.com/basic-auth/uc6-user/uc6-demo-only
  (platform/overlays/zrh-gw/uc6-security/backend). 200 for valid credentials,
  any other status denies. IP blocklisting is not possible here: the gateway
  sees only IBM's Envoy ingress (10.24.2.5 as peer and in X-Forwarded-For,
  tested 26.10.).
